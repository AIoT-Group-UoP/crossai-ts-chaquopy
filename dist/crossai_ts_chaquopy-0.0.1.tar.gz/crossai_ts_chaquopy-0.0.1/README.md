# CrossAI Time Series for Chaquopy SDK for Android

## Introduction

This is a version of the CrossAI-TS Python library that provides capable of
running on Android devices using the Chaquopy SDK.

## Installation

```text
```